**To set the health status of an instance**

This example sets the health status of the specified instance to ``Unhealthy``::

    aws autoscaling set-instance-health --instance-id i-93633f9b --health-status Unhealthy
